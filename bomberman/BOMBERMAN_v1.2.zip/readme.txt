BOMBERMAN for NGPC (v1.2)
CopyLeft Thor 08/2026

Pad : move
A: drop bomb
B: PAUSE
Option : while pause = return to title screen, else, go to next level (if open)

New in 1.2: Duel mode (thx to Ahchay & Tixul)

Gfx rips from various Bomberman versions (jBomber, SNES, ...), zelda, metroid
Videos from GC version (or N64, don't really know...)
Musics : MetalSlug 1, Magical drop, Cotton

Greetings to Ivan Mackintosh, Flavor, MrSpiv, Hooka, Judge, Chris Ahchay, Kojote, Lo�c Julien, Tixul & Napomex 

email: rtb7@yahoo.com

