BOMBERMAN for NGPC (v1.1)
CopyLeft Thor 08/2004

Pad : move
A: drop bomb
B: PAUSE
Option : while pause = return to title screen, else, go to next level (if open)

Gfx rips from various Bomberman versions (jBomber, SNES, ...), zelda, metroid
Videos from GC version (or N64, don't really know...)
Musics : MetalSlug 1, Magical drop, Coton

Greetings to Ivan Mackintosh, Flavor, MrSpiv, Hooka, Judge, Chris Archay, Kojote, Lo�c Julien
Thanks to www.pdroms.de, www.wonderpocket.fr.st, www.consoles-portables.com

email: rtb7@yahoo.com
www: www.geocities.com/rtb7
