ANOTHER DAY IN HELL

By THOR (code & gfx) and ICEMAN (Gfx)

PDROMS COMPO #3
with WWW.CONSOLEFEVER.COM

Thanks to Ivan Macintosh, Flavor, Mr. Spiv, Kojote

The game is not finished yet, some parts have been commented (bugs...)
Only 1 level with one boss.
No music

I'm already happy to have something to present to the compo. 
