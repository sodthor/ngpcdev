************************************************************
* MIX! for NGPC
*
* Version 1.0
*
************************************************************
*
* COPYLEFT THOR NOVEMBER 2011
* 
* Music ripped from :
*    Bust A Move
*    Cotton
*    MetalSlug
*    Magical drop
*
************************************************************

NGPC rom including 3 puzzle games, a new one, Vexed,
 and 2 old one repackaged to share the same memory.

The 3 games have the same game play :
    slide elements with button + direction
    option button to pause/abort/restart game

Read other readme files for each game.

Thor
