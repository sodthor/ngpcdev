******************************************************************************

VEXED v1.0

COPYLEFT THOR NOVEMBER 2011

BASED ON AN ORIGINAL GAME ON PALM AND SOME OTHER PORTS LIKE:

    http://oos.moxiecode.com/examples/vexed/

******************************************************************************

CODE: THOR
MUSIX: ripped from METALSLUG
GFX: THOR

Thanx to : Flavor, Ivan (musix ripper, c framework)

******************************************************************************


HOW TO PLAY:

Join same color tiles to remove them, and clear each level.

Push button A and a direction (right/left) : the selected tile will slide to the selected direction.
Push button B to reset the level
Press Option button to pause game, go back to menu, check solution or change level.

Have fun !

THOR
