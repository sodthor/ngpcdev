******************************************************************************

PUZZLE GEMS

COPYLEFT THOR APRIL 2003

BASED ON
  BEJEWELED (POP CAP GAMES : www.popcap.com)
  PIRATE GEMS (http://www.prizegames.com)

******************************************************************************

CODE: THOR
MUSIX: ripped from MAGICAL DROP
GFX: THOR, MADXX and some ripped from the original games

Thanx to : Flavor, Ivan (musix ripper, c framework)

Sources on request (rtb7@yahoo.com)

******************************************************************************

v1.1 :
	BIG bug fixed (borders swap not tested :)
	score bonus when level up

******************************************************************************

HOW TO PLAY:

You have to build vertical or horizontal blocks of at least 3 gems by swapping
2 gems : choose the gems to swap with the cursor, push button A and a
direction (right/left/up/down) : the selected gem will swap with the one
in the selected direction.

2 kind of games :

Original : You have a limited number of swaps. Each combo gives new credits.
           The game stops when there is no swap or no possible move left.

Time trial : Time allowed to play decrease, each block erased gives more time.
             The game stops when there is no time or no possible move left.

Combos and "level up" give you more points.

Press Option button to pause game.

Have fun !

THOR
