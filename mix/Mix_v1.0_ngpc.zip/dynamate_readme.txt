************************************************************
* DYNAMATE for NGPC
* Version 1.1
************************************************************
*
* Original game by Jonas Norberg & Bjorn Halzen (amiga)
*
* NGPC porting by Thor
* 
* Music ripped from "Bust A Move"
*
************************************************************
* Thanx to Flavor, Ivan and Jonas
************************************************************

How to play ?

. Watch the "Rules" in the game !
. Stuck blocks have a small ring around them (it can be
  difficult to see, but if you can't move a block, it should
  be stuck!).
. You have to clear all colored blocks in the level.
. Call the menu by pressing OPTION during the game.
  In the menu, you can reset the current level or select a
  level you have already cleared (to break records!).
  To return to main menu, press B in the menu.

What's new in this realease ?

. One version for emu and real hardware with autodetection
. Exit from tutorial : press A or B

What will be done in the next releases ?

. Tell me what is not good enough for you, I will try to fix it.
. better gfx, and my "own" musix.

Have fun !

THOR

rtb7@yahoo.com
